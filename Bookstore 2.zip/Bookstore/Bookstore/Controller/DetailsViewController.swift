//
//  DetailsViewController.swift
//  Bookstore
//
//  Created by Grupa 1 on 31/01/2024.
//

import UIKit

class DetailsViewController: UIViewController {

    @IBOutlet weak var lblBookName: UILabel!
    @IBOutlet weak var lblGenre: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var tvDescription: UITextView!
    @IBOutlet weak var lblYearOfBookRelease: UILabel!
    @IBOutlet weak var btnAddToCart: UIButton!
    
    var bookDetails : Book?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

      if let bookDetails =
            bookDetails{
        self.lblBookName.text = bookDetails.bookName
        self.lblGenre.text = bookDetails.genre
        self.imgView.image = UIImage(data: bookDetails.imageName)!
        self.lblPrice.text = "\(bookDetails.price) RSD"
        self.tvDescription.text = bookDetails.description
        self.lblYearOfBookRelease.text = "Year: \(bookDetails.yearOfRelease)"
        
      }
    }
    

    @IBAction func btnAdd(_ sender: Any) {
        
        let navigacija = self.tabBarController?.viewControllers![1] as! UINavigationController
        
        let porudzbina = navigacija.viewControllers[0] as! OrderViewController
        
        porudzbina.knjigeUKorpi.append(bookDetails!)
        
        let itemi = self.tabBarController?.tabBar.items
        let korpaItem = itemi?[1] as! UITabBarItem
        korpaItem.badgeValue = "\(porudzbina.knjigeUKorpi.count)"
        korpaItem.badgeColor = .blue
    }
    
    @IBAction func btnShareTapped(_ sender: Any) {
        let slika = imgView.image //podatak koji prosledjujemo u niz
        
        let activityVC = UIActivityViewController(activityItems: [slika], applicationActivities: nil) //prvo definisemo sistemski view kontroler
        
        self.present(activityVC, animated: true) //prikaz sistemskog view controllera
    }
}
