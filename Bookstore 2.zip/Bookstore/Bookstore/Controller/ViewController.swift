//
//  ViewController.swift
//  Bookstore
//
//  Created by Ana Asceric on 30.1.24..
//

import UIKit
import SafariServices
import CoreData

class BookCell: UITableViewCell{
    
    @IBOutlet weak var bookImageView: UIImageView!
    
    @IBOutlet weak var lblBookName: UILabel!
    
    
    @IBOutlet weak var lblGenre: UILabel!
    
    @IBOutlet weak var lblPrice: UILabel!
}
class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ukupanBrojRedova.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celija = tableView.dequeueReusableCell(withIdentifier: "book_cell") as! BookCell
        
        //definisemo kako ce izgledati, sta ce posedovati od podataka i vracamo je kao povratnu vrednost
        
        let podaciUCeliji = ukupanBrojRedova[indexPath.row]
        
        celija.bookImageView.image = UIImage(data:podaciUCeliji.imageName)!
        celija.lblBookName.text=podaciUCeliji.bookName
        celija.lblGenre.text = podaciUCeliji.genre
        celija.lblPrice.text = "\(podaciUCeliji.price) RSD"
        
        return celija
    }
    
    
    

    @IBOutlet weak var tableView: UITableView!
    
    
    @IBOutlet weak var btnEdit: UIBarButtonItem!
    
    
    var ukupanBrojRedova = ForSale.allBooks //ukupan broj redova u sekciji ce biti broj clanova u nizu allBooks
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.isEditing=false // nije u stanju izmene
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        ukupanBrojRedova.removeAll()
        procitajPodatke()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Klik na celiju")
        print("indeks reda je \(indexPath.row)")
        
        izabranaKnjiga = ukupanBrojRedova[indexPath.row]
        performSegue(withIdentifier: "detalji", sender: self) //prelazak u drugi kontroler
  
    }
    
    var izabranaKnjiga: Book?
    
    override func prepare(for segue: UIStoryboardSegue, sender:Any?)
    {
        if segue.identifier == "detalji"{
            if let destinacija = segue.destination as? DetailsViewController{
                destinacija.bookDetails = izabranaKnjiga
            }
        }
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // dobijanje knjige koja treba biti izbrisana iz baze
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                return
            }

            let context = appDelegate.persistentContainer.viewContext
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "BookMO")

            do {
                let rezultati = try context.fetch(request)

                if let rezultati = rezultati as? [NSManagedObject], rezultati.count > 0 {
                    let knjigaZaBrisanje = rezultati[indexPath.row]
                    context.delete(knjigaZaBrisanje)

                    do {
                        try context.save()

                      //brisanje knjige i iz niza
                        ukupanBrojRedova.remove(at: indexPath.row)

                       //nakon azuriranja podataka, azuriramo tabelu
                        tableView.deleteRows(at: [indexPath], with: .automatic)
                    } catch {
                        print("Greska pri save-u nakon brisanja: \(error.localizedDescription)")
                    }
                }
            } catch {
                print("Greska pri dohvatanju podataka: \(error.localizedDescription)")
            }
        }
    }

//    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
//        return true
//    }

    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    
    @IBAction func btnEditPressed(_ sender: Any) {
        tableView.isEditing = !tableView.isEditing
        
        if tableView.isEditing{
            btnEdit.title = "Done"
            
        }
        else{
            btnEdit.title = "Edit"
        }    }
    
//    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
//        let knjiga = ukupanBrojRedova[sourceIndexPath.row]
//        ukupanBrojRedova.remove(at: sourceIndexPath.row)
//        ukupanBrojRedova.insert(knjiga, at: destinationIndexPath.row)
//
//    }
    
    
    @IBAction func btnDiscoverMoreTapped(_ sender: Any) {
        let url = URL(string:"https://www.knjizare-vulkan.rs")
        let safariVC = SFSafariViewController(url:url!)
        self.present(safariVC, animated: true)
    }
    
    func procitajPodatke() {
            if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
                let context = appDelegate.persistentContainer.viewContext
                
                let request = NSFetchRequest<NSFetchRequestResult>(entityName: "BookMO")
                do {
                    let rezultati = try context.fetch(request)
                    
                    if rezultati.count > 0 {
    
                        for rezultat in rezultati as! [NSManagedObject] {
                            
                            let bookName = rezultat.value(forKey: "bookName") as? String ?? ""
                            let genre = rezultat.value(forKey: "genre") as? String ?? ""
                            let price = rezultat.value(forKey: "price") as? Float ?? 0.0
                            let image = rezultat.value(forKey: "image")  as? Data ?? Data()
                            let yearOfRelease = rezultat.value(forKey: "yearOfRelease") as? Int ?? 2023
                            let description = rezultat.value(forKey: "descr") as? String ?? ""
                            
                            let ucitanaKnjiga = Book(bookName: bookName, genre:genre, author: "", numberOfPages: 0, yearOfRelease: yearOfRelease, price: Double(price), imageName: image, description: description)
                            
                            ukupanBrojRedova.append(ucitanaKnjiga)
                        }
                       tableView.reloadData() // osvezava table view sa novim podacima
                    }
                    
                } catch {
                    print("Error")
                }
               
            }
        }
    
}

