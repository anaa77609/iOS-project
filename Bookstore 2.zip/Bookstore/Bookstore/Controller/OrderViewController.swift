//
//  OrderViewController.swift
//  Bookstore
//
//  Created by Grupa 1 on 01/02/2024.
//

import UIKit

class OrderItemCell : UITableViewCell{
    
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var lblBookName: UILabel!
    
    
    @IBOutlet weak var lblGenre: UILabel!
    
    @IBOutlet weak var lblPrice: UILabel!
    
}

class OrderViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    @IBOutlet weak var tableView: UITableView!
    
    var knjigeUKorpi = [Book]()
    
    override func viewWillAppear(_ animated: Bool) {
        tableView.reloadData()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return knjigeUKorpi.count
    } //broj redova
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celija = tableView.dequeueReusableCell(withIdentifier: "cart_cell") as! OrderItemCell
        
        let podaciUCeliji = knjigeUKorpi[indexPath.row]
        
        celija.imgView.image = UIImage(data: podaciUCeliji.imageName)!
        celija.lblBookName.text = podaciUCeliji.bookName
        celija.lblGenre.text = podaciUCeliji.genre
        celija.lblPrice.text = "\(podaciUCeliji.price) RSD"
        
        return celija
        
        //definisemo celiju kako ce izgledati, sta ce posedovati od podataka i vracamo je kao povratnu vrednost
        
    }


    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    
   
    @IBAction func btnConfirmTapped(_ sender: Any) {
        var ukupnaCena: Double = 0.0
        print("Submit taster")
//        if knjigeUKorpi.count == 0 {
//            print("Korpa je prazna")
//        }
//        else
//        {
//            for knjiga in knjigeUKorpi{
//                ukupnaCena+=knjiga.price
//            }
//
//            print("Success! Total price: \(ukupnaCena)")
//
//            knjigeUKorpi.removeAll()
//
//            let itemi = self.tabBarController?.tabBar.items
//            let korpaItem = itemi?[1] as! UITabBarItem
//            korpaItem.badgeValue = nil
//            tableView.reloadData()
//              }
        
//        let alert = UIAlertController(title: "Ovo je naslov", message: "poruka", preferredStyle: .actionSheet)
//        let okBtn = UIAlertAction(title: "OK", style: .default) { _ in
//
//            print("Klinula sam na ok")
//                alert.dismiss(animated: true)
//        }
//        alert.addAction(okBtn)
//
//        let cancelButton = UIAlertAction(title: "Cancel", style: .destructive, handler: nil)
//
//        alert.addAction(cancelButton)
//        self.present(alert, animated: true)
//
//        //sakrij nakon pet sekundi
//
//        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+5){
//            alert.dismiss(animated: true, completion: nil)
//}
//
    
        if knjigeUKorpi.count == 0
        {
            let alert = UIAlertController(title: "Korpa je prazna", message: nil, preferredStyle: .alert)
            
            self.present(alert, animated:true)
            
            //sakrij nakon pet sekundi
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+5){
                       alert.dismiss(animated: true, completion: nil)
                
            }}
        else{
            for knjiga in knjigeUKorpi {
                ukupnaCena+=knjiga.price
            }
            let alert = UIAlertController(title: "Ukupna cena", message: "\(ukupnaCena) RSD", preferredStyle: .alert)
            
            let akcija1 = UIAlertAction(title: "Potvrdite", style: .default)
            {
                _ in self.knjigeUKorpi.removeAll()
                let itemi = self.tabBarController?.tabBar.items
                let korpaItem = itemi![1]
                korpaItem.badgeValue = nil
                
                self.tableView.reloadData()
            }
            
            let akcija2 = UIAlertAction(title: "Odustanite", style: .destructive, handler:nil)
            
            alert.addAction(akcija1)
            alert.addAction(akcija2)
           
            self.present(alert,animated:true)
        }
    }
}



