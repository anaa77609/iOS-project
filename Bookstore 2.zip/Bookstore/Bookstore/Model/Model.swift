//
//  Model.swift
//  Bookstore
//
//  Created by Ana Asceric on 30.1.24..
//

import Foundation
import UIKit

struct Book{
    
    var bookName:String
    var genre:String
    var author:String
    var numberOfPages:Int
    var yearOfRelease: Int
    var price:Double
    var imageName: Data
    var description: String
    
}
struct ForSale{
    static var allBooks = [
        Book(bookName: "Grad pobede", genre: "Klasici", author:"Salman Ruzdi", numberOfPages: 336, yearOfRelease: 2023, price: 1104.00, imageName:UIImage(named:"gradPobede")!.jpegData(compressionQuality: 1.0)!, description: "Sakrivena u glinenom ćupu. Zapečaćena voskom. Sahranjena u srcu srušene palate usred pepela jedne od najvećih, skoro zaboravljenih imperija Indije. Priča koja čeka da bude ispričana.U četrnaestom veku naše ere, na jugu zemlje koju danas zovemo Indija, devetogodišnja Pampa Kampana, koja je ostala siroče posle rata između dva zaboravljena kraljevstva, počinje da čuje glas drevne boginje i menja tok istorije. Inspirisana i prožeta moćnom magijom, ona se zaklinje da više nijedna žena neće doživeti tragičnu sudbinu njene voljene majke."),
        Book(bookName: "Ispod povrsine", genre: "Roman", author:"Dejzi Dzonson", numberOfPages: 307, yearOfRelease: 2023, price:891.00, imageName:UIImage(named:"ispodPovrsine")!.jpegData(compressionQuality: 1.0)!, description: "Ispod površine može se čitati i kao moderna verzija Kralja Edipa. Autorka će uglavnom zadržati sve motive, ali će ih dobro promešati u bubnju 21. veka. Simbolički potencijal romana tako postaje riznica drugačija od antičke. Zabuna dovodi do tragedije i u ovom delu, ali preispitivanje rodnog identiteta junakinja i junaka jeste novi ključ za dešifrovanje sudbina. Antički Tiresija je nekoliko godina bio pretvoren u ženu i njegov lik odavno već nameće razmišljanja o rodnom prožimanju, ograničenjima i cenzuri."
             
),
        Book(bookName: "Peti pecat", genre: "Istorijski roman", author: "Davide Kosu", numberOfPages: 213, yearOfRelease: 2023, price: 809.00, imageName:UIImage(named:"petiPecat")!.jpegData(compressionQuality: 1.0)!, description:"Firenca, kolevka renesanse, godina 1439. Tokom veoma osetljivog, istorijskog ekumenskog sabora, koji se zbog kuge preselio iz Ferare u srce Toskane, uznemirujući događaj preti da izazove nove, veoma opasne napetosti između Rimske i Grčke crkve: dvadesetogodišnji grčki izaslanik izgubio je život survavši se s kupole Santa Marije del Fjore. Kozimo de Mediči odmah je zadužio Leona Batistu Albertija, čuvenog po britkom umu, da u potaji sprovede istragu tog nasilnog slučaja. Tragovi na vratu žrtve uskoro prisiljavaju Leona Batistu da izvesti Kozima kako prvobitnu pretpostavku o samoubistvu moraju da odbace."),
        Book(bookName: "Tajna trgovca knjigama", genre: "Triler", author: "Marcelo Simoni", numberOfPages: 343, yearOfRelease: 2023, price: 1188.00, imageName:UIImage(named:"tajnaTrgovcaKnjigama")!.jpegData(compressionQuality: 1.0)!, description: "Leto Gospodnje 1234. Posle dve godine provedene na dvoru Fridriha II na Siciliji,trgovac relikvijama Injacio iz Toleda vraća se u Španiju zbog novog opasnog poduhvata: treba da nađe pećinu Sedam usnulih. U tom legendarnom grobu, sedmorica hrišćanskih mučenika doslovno su usnuli, utonuvši u večni san pre mnogo vekova. Ali trgovca svakako nije pokrenula potraga za nekom relikvijom, već ga je podstakla tajna besmrtnosti koja se naoko skriva iza priča o Sedam usnulih.")
          
          
         
          ]
    
}
