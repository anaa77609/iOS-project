//
//  BookMO+CoreDataClass.swift
//  Bookstore
//
//  Created by Ana Asceric on 3.2.24..
//
//

import Foundation
import CoreData

@objc(BookMO)
public class BookMO: NSManagedObject {

}
