//
//  BookMO+CoreDataProperties.swift
//  Bookstore
//
//  Created by Ana Asceric on 3.2.24..
//
//

import Foundation
import CoreData


extension BookMO {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<BookMO> {
        return NSFetchRequest<BookMO>(entityName: "BookMO")
    }

    @NSManaged public var yearOfRelease: Int32
    @NSManaged public var price: Double
    @NSManaged public var genre: String?
    @NSManaged public var bookName: String?
    @NSManaged public var image: Data?
    @NSManaged public var descr: String?

}

extension BookMO : Identifiable {

}
